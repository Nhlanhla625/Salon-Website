# Salon-App
Salon App is a Kotlin-based mobile application designed to streamline salon management. It enables booking appointments, managing customer profiles, tracking services, and viewing schedules. With a sleek UI, secure data storage, it’s the perfect tool for modern salons to enhance customer experience and efficiency.
